export const albumsData = [
  { id: 1, name: "test album one" },
  { id: 2, name: "test album two" },
  { id: 3, name: "test album three" },
  { id: 4, name: "test album four" },
  { id: 5, name: "test album five" },
  { id: 6, name: "test album six" },
  { id: 7, name: "test album seven" },
  { id: 8, name: "test album eight" },
];

export const imagesData = [
  {
    id: 1,
    url: "https://images.pexels.com/photos/745243/pexels-photo-745243.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    title: "test image one",
  },
  {
    id: 2,
    url: "https://images.pexels.com/photos/466685/pexels-photo-466685.jpeg?auto=compress&cs=tinysrgb&w=600",
    title: "test image two",
  },
  {
    id: 3,
    url: "https://images.pexels.com/photos/378570/pexels-photo-378570.jpeg?auto=compress&cs=tinysrgb&w=600",
    title: "test image three",
  },
  {
    id: 4,
    url: "https://images.pexels.com/photos/2190283/pexels-photo-2190283.jpeg?auto=compress&cs=tinysrgb&w=600",
    title: "test image four",
  },
  {
    id: 5,
    url: "https://images.pexels.com/photos/1557547/pexels-photo-1557547.jpeg?auto=compress&cs=tinysrgb&w=600",
    title: "test image five",
  },
  {
    id: 6,
    url: "https://images.pexels.com/photos/1770775/pexels-photo-1770775.jpeg?auto=compress&cs=tinysrgb&w=600",
    title: "test image six",
  },
];
